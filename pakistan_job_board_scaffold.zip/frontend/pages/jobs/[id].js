
import { useRouter } from 'next/router'
import useSWR from 'swr'
const fetcher = (url) => fetch(url).then(r=>r.json())

export default function JobDetail(){
  const router = useRouter()
  const { id } = router.query
  const { data: job, error } = useSWR(id ? '/api/job/'+id : null, fetcher)
  if(error) return <div>Error</div>
  if(!job) return <div>Loading...</div>
  return (
    <div style={{maxWidth:800, margin:'0 auto', padding:20}}>
      <h1>{job.title}</h1>
      <div style={{color:'#666'}}>{job.source} • {job.location}</div>
      <p>{job.full_text || job.summary}</p>
      <a href={job.apply_link} target="_blank" rel="noreferrer">Apply / Read Original</a>
    </div>
  )
}
