
import useSWR from 'swr'
import Link from 'next/link'

const fetcher = (url) => fetch(url).then(r=>r.json())

export default function Home(){
  const { data: jobs, error } = useSWR('/api/jobs', fetcher)
  if(error) return <div>Error loading</div>
  if(!jobs) return <div>Loading...</div>
  return (
    <div style={{maxWidth:800, margin:'0 auto', padding:20}}>
      <h1>Pakistan Jobs & Scholarships - Latest</h1>
      <ul style={{listStyle:'none', padding:0}}>
        {jobs.map(job => (
          <li key={job._id} style={{padding:12, borderBottom:'1px solid #eee'}}>
            <Link href={'/jobs/'+job._id}><a><h3>{job.title}</h3></a></Link>
            <div style={{fontSize:12, color:'#666'}}>{job.source} • {job.location || 'Pakistan'}</div>
            <p>{job.summary}</p>
          </li>
        ))}
      </ul>
    </div>
  )
}
