
Frontend (Next.js) README

Install:
  cd frontend
  npm install

Run dev:
  npm run dev

Notes:
- The frontend expects the backend API to be reachable under /api in development (you can use a proxy or run backend on :4000 and change fetch URLs).
- For production, deploy frontend on Vercel and backend on Render/Railway and set correct API_BASE.
