
/**
 * Example scraper using axios + cheerio.
 * NOTE: You must adapt selectors to the target site's HTML.
 * Respect robots.txt and site terms. Use responsibly.
 */
const axios = require('axios');
const cheerio = require('cheerio');
const { MongoClient } = require('mongodb');
const dayjs = require('dayjs');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017';
const DB = 'jobboard';
const client = new MongoClient(MONGODB_URI);

async function fetchHome(){
  const url = 'https://www.pakistanjobsbank.com/'; // example
  const { data } = await axios.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; JobScraper/1.0)' } });
  const $ = cheerio.load(data);
  const jobs = [];
  // === BEGIN: you must adjust selectors below to match the real site ===
  // This is a generic example: find links inside article blocks
  $('article, .post, .job-item').each((i, el) => {
    const a = $(el).find('a').first();
    const title = a.text().trim();
    const href = a.attr('href');
    const summary = $(el).find('p').first().text().trim() || '';
    const dateText = $(el).find('.date, time').first().text().trim() || '';
    const date_posted = dateText ? dayjs(dateText).toDate() : new Date();
    if(title && href){
      jobs.push({ title, summary, scrape_source_url: href, date_posted, source: 'PakistanJobsBank' });
    }
  });
  return jobs;
}

async function upsertJobs(jobs){
  await client.connect();
  const col = client.db(DB).collection('jobs');
  for(const j of jobs){
    await col.updateOne({ scrape_source_url: j.scrape_source_url }, { $set: { ...j, created_at: new Date() } }, { upsert:true });
  }
  console.log('Upserted', jobs.length);
  await client.close();
}

(async ()=>{
  try{
    const jobs = await fetchHome();
    if(jobs.length) await upsertJobs(jobs);
    else console.log('No jobs found - check selectors.');
  }catch(e){ console.error(e); process.exit(1); }
})();
