
Backend (Express) README

Install:
  cd backend
  npm install

Run development server:
  npm run dev

Scraper:
  node scraper.js
  # edit scraper.js to match selectors for your target site

Env:
  Copy .env.example to .env and set MONGODB_URI
