
/**
 * Simple Express API for jobs
 * Run: node server.js
 * Make sure MONGODB_URI is set in environment or .env (use dotenv in production).
 */
const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017';
const DB = 'jobboard';
const client = new MongoClient(MONGODB_URI);

async function connectDb(){ if(!client.topology) await client.connect(); }
app.get('/api/health', (req,res)=> res.json({ok:true}));

// GET /api/jobs?q=&location=&page=1&per=20
app.get('/api/jobs', async (req,res)=>{
  await connectDb();
  const { q, location, page=1, per=20 } = req.query;
  const filter = {};
  if(q) filter.$text = { $search: q };
  if(location) filter.location = location;
  const col = client.db(DB).collection('jobs');
  const jobs = await col.find(filter).sort({ date_posted:-1 }).skip((page-1)*per).limit(parseInt(per)).toArray();
  res.json(jobs);
});

app.get('/api/job/:id', async (req,res)=>{
  await connectDb();
  const col = client.db(DB).collection('jobs');
  const job = await col.findOne({ _id: new ObjectId(req.params.id) });
  res.json(job);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('API running on', PORT));
