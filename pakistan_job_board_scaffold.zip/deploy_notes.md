
Local development (recommended):
1. Install Node.js (v18+) and npm.
2. Backend:
   cd backend
   npm install
   cp .env.example .env && edit .env (MONGODB_URI, PORT)
   npm run dev
3. Frontend:
   cd frontend
   npm install
   npm run dev
4. Scraper (manual):
   NODE_ENV=development node backend/scraper.js
5. To create production cron, use GitHub Actions, Render cron jobs, or a small VPS cron calling `node backend/scraper.js` daily.

Files of interest:
- backend/scraper.js : example scraper (needs selector tuning)
- backend/server.js  : simple Express API exposing /api/jobs and /api/job/:id
- frontend/pages/index.js : Next.js home listing
- frontend/pages/jobs/[id].js : Job detail page (SSG/SSR suggestion in comments)
